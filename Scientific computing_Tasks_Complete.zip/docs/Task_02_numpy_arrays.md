# Task 2: NumPy Arrays and Numerical Computation

Programs: `code/Task_02_numpy_arrays.py` (original) and `code/Task_02_farm_rainfall.py` (new real-world case)

## B. Inputs and mathematical operations

The input is one array of 24 hourly temperatures in degrees Celsius. The program finds the mean, the minimum and the maximum of the array. It then converts every reading to Fahrenheit with F = 1.8C + 32. The conversion is applied to the whole array in one line, with no loop.

## Original output

When I ran the original program, it printed:

```
Daily mean temperature: 23.12 C
Minimum temperature: 17.50 C
Maximum temperature: 29.40 C
First six Fahrenheit readings: [65.3  64.4  64.04 63.5  64.22 66.2 ]
```

## C. Changing the inputs

I changed the 13th reading (the afternoon peak) from 29.4 to 35.0 and ran the program again.

| Result | Original | After the change |
|---|---|---|
| Mean temperature | 23.12 C | 23.35 C |
| Minimum temperature | 17.50 C | 17.50 C |
| Maximum temperature | 29.40 C | 35.00 C |
| First six Fahrenheit readings | unchanged | unchanged |

The mean went up by about 0.23. That is because one reading rose by 5.6, and the mean shares that rise over 24 readings (5.6 / 24). The maximum became the new value. The minimum did not change, because the changed reading was not the lowest. The first six Fahrenheit values did not change, because the 13th reading is not one of them.

## D. Meaning of the output

The mean of 23.12 C tells us the typical temperature of the day. The minimum and maximum show the range, from 17.50 C in the early morning to 29.40 C in the afternoon. The Fahrenheit values show that one formula was applied to every reading at once. An array lets the computer treat the whole day of readings as one object.

## E. Modified real-world case

### New assumptions

- A farm has a rain gauge that records rainfall in millimetres for 12 days.
- The farm covers 2,000 square metres (assumed).
- 1 mm of rain on 1 square metre gives 1 litre of water.
- The rainfall values are assumed illustrative values, not measured data.

### Input data

Rainfall in mm for 12 days: 0.0, 0.0, 12.5, 8.0, 0.0, 3.2, 25.4, 0.0, 0.0, 5.1, 14.8, 0.0. Farm area: 2,000 square metres.

### Output

```
Total rainfall: 69.0 mm
Mean daily rainfall: 5.75 mm
Wettest day: day 7 with 25.4 mm
Total water received by the farm: 138,000 litres
```

### Interpretation

The farm received 69.0 mm of rain in 12 days, which is 5.75 mm per day on average. Day 7 was the wettest, with 25.4 mm. Because 1 mm on one square metre is 1 litre, the whole farm received 138,000 litres. The program works this out for every day at once by multiplying the whole array by the farm area. A farmer could use this to decide whether irrigation is needed.
