# Task 17: Ordinary Differential Equations - Euler Method

Programs: `code/Task_17_euler_ode.py` (original) and `code/Task_17_drug_decay.py` (new real-world case)

## B. Inputs and mathematical operations

The model is Newton's law of cooling: dT/dt = -k(T - T_ambient). The inputs are an ambient temperature of 25 C, a starting temperature of 90 C, k = 0.12 per minute, a step size h of 1 minute and an end time of 30 minutes. Euler's method takes small steps: each new temperature equals the old temperature plus h times the rate of change. The program compares the Euler answer with the exact solution.

## Original output

When I ran the original program, it printed:

```
Euler temperature after 30 min: 26.40 C
Exact temperature after 30 min: 26.78 C
Final absolute error: 0.3720 C
```

## C. Changing the inputs

I changed the step size h from 1.0 to 0.5, and then to 2.0.

| Step size h | Euler temperature at 30 min | Exact | Absolute error |
|---|---|---|---|
| 2.0 | 26.06 C | 26.78 C | 0.7165 C |
| 1.0 (original) | 26.40 C | 26.78 C | 0.3720 C |
| 0.5 | 26.59 C | 26.78 C | 0.1890 C |

A smaller step gives a smaller error. When h was halved, the error roughly halved as well. A smaller step is more accurate but needs more steps to reach the end, so it costs more computing.

## D. Meaning of the output

After 30 minutes the object has cooled from 90 C to about 26.4 C according to Euler, close to the exact 26.78 C and close to the room temperature of 25 C. On the graph, both curves fall quickly at first and then flatten near 25 C. The Euler line stays slightly below the exact curve, because each step uses the rate at the start of the step.

![Cooling of a hot object](Task_17_graph.png)

## E. Modified real-world case

### New assumptions

- A drug is given and its concentration in the blood falls as dC/dt = -kC.
- The starting concentration is 200 mg/L and k = 0.2 per hour (both assumed).
- The step size is 0.5 hours, for 12 hours.

### Input data

C0 = 200 mg/L, k = 0.2 per hour, h = 0.5 hours, end time 12 hours.

### Output

```
Euler concentration after 12 h: 15.95 mg/L
Exact concentration after 12 h: 18.14 mg/L
Final absolute error: 2.190 mg/L
```

### Interpretation

After 12 hours Euler gives 15.95 mg/L, while the exact answer is 18.14 mg/L, an error of 2.19 mg/L. About 9% of the drug remains. Euler underestimates here, as it did for the cooling object. The error is larger here because the concentration starts at 200 and the steps cover 12 hours, so the small error of each step adds up. A doctor would use a smaller step or a better method for a real dosage calculation.

![Drug concentration decay](Task_17_drug_graph.png)
