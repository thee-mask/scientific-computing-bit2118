# Task 20: Random Numbers and Monte Carlo Methods

Programs: `code/Task_20_monte_carlo.py` (original) and `code/Task_20_clinic_arrivals.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are a server capacity of 1,000, a mean demand of 850 with a standard deviation of 120 (demand is normally distributed), 100,000 simulated scenarios and a random seed of 42. The program generates random demands, marks each as overloaded if it is above capacity, and takes the fraction of overloaded cases as the probability. It also computes a running estimate to show how the estimate settles as more simulations are done.

## Original output

When I ran the original program, it printed:

```
Estimated overload probability: 10.6160%
Number of overload cases: 10616 out of 100000
```

## C. Changing the inputs

I changed one input at a time and ran the program again.

| Run | Change | Probability | Overload cases |
|---|---|---|---|
| 0 | Original | 10.6160% | 10616 |
| 1 | capacity = 900 | 33.5940% | 33594 |
| 2 | mean demand = 800 | 4.8250% | 4825 |
| 3 | standard deviation = 80 | 3.1140% | 3114 |
| 4 | N = 1000 simulations | 10.1000% | 101 of 1000 |
| 5 | seed = 123 | 10.6200% | 10620 |

Less capacity means more overloads. Lower demand means fewer overloads. Less variation means fewer extreme days, so fewer overloads. With only 1,000 simulations the estimate is 10.1%, a bit off the 10.6% found with 100,000. A different seed moved the answer only slightly, which shows that a large number of simulations gives a stable result.

## D. Meaning of the output

The program estimates that the server is overloaded on about 10.6% of occasions, which is about 1 in 9. The graph shows the running estimate: it jumps around when there are few simulations, then settles near 0.106 as the number of simulations grows. This is the law of large numbers: more random samples give a more reliable estimate.

![Monte Carlo estimate of server-overload risk](Task_20_graph.png)

## E. Modified real-world case

### New assumptions

- A clinic can see 55 patients a day.
- The number of patients arriving each day is random and follows a Poisson distribution with a mean of 45 (assumed).
- Each day is independent of the others.
- 100,000 days are simulated, with a seed of 42.

### Input data

Capacity: 55 patients per day. Mean arrivals: 45 per day. Simulated days: 100,000.

### Output

```
Estimated probability of overload: 6.2910%
Overloaded days: 6291 out of 100000
Expected overloaded days in a 30-day month: 1.89
Capacity vs overload probability:
  50 patients -> 20.3980%
  55 patients -> 6.2910%
  60 patients -> 1.2740%
  65 patients -> 0.1740%
  70 patients -> 0.0160%
```

### Interpretation

The clinic is overloaded on about 6.29% of days, which is about 1.89 days in a 30-day month. Raising the capacity to 60 patients cuts the risk to 1.27%, and to 65 patients to 0.17%. The risk falls quickly at first and then slowly, so each extra place helps less. A clinic manager could use this to decide how many staff or beds to plan for, balancing cost against the risk of turning patients away. The results depend on the assumed mean of 45.

![Clinic overload estimate](Task_20_clinic_graph.png)
