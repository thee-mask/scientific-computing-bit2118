# Task 5: Matrix Algebra and Matrix Operations

Programs: `code/Task_05_matrix_algebra.py` (original) and `code/Task_05_plot_map.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are the four corners of a unit square, a rotation of 45 degrees, and a scaling of 2 horizontally and 1.5 vertically. The program builds a rotation matrix and a scaling matrix, multiplies them to get one combined matrix, and uses that matrix to move all four corners at once. It also finds the determinant of the combined matrix.

## Original output

When I ran the original program, it printed:

```
Original points:
 [[0. 0.]
 [1. 0.]
 [1. 1.]
 [0. 1.]]
Transformation matrix:
 [[ 1.41421356 -1.06066017]
 [ 1.41421356  1.06066017]]
Transformed points:
 [[ 0.          0.        ]
 [ 1.41421356  1.41421356]
 [ 0.35355339  2.47487373]
 [-1.06066017  1.06066017]]
Determinant: 2.9999999999999996
```

## C. Changing the inputs

I changed the rotation angle from 45 degrees to 90 degrees.

| Result | 45 degrees | 90 degrees |
|---|---|---|
| Corner (1, 0) moves to | (1.414, 1.414) | (0, 2) |
| Corner (0, 1) moves to | (-1.061, 1.061) | (-1.5, 0) |
| Corner (1, 1) moves to | (0.354, 2.475) | (-1.5, 2) |
| Determinant | 3.0 | 3.0 |

The shape turned further, so the corners landed in new places. The determinant stayed at 3 because it depends only on the scale factors (2 x 1.5), not on the angle. In the 90 degree run, some numbers printed as tiny values like 1.2e-16 instead of exactly 0. This is floating-point round-off error, the same effect we saw in Task 4.

## D. Meaning of the output

The determinant of 3 means the square's area is multiplied by 3: its area of 1 becomes 3. Rotation only turns a shape and does not change its area, so only the scaling affects the determinant. The program moves all four points with one matrix multiplication, which is why matrices are used in computer graphics.

## E. Modified real-world case

### New assumptions

- A rectangular plot of land measures 40 m by 25 m.
- It must be drawn on a map, rotated 30 degrees and scaled to 1/10 of its size.
- The dimensions and the angle are assumed illustrative values.

### Input data

Corners of the plot in metres: (0, 0), (40, 0), (40, 25), (0, 25). Rotation: 30 degrees. Scale factor: 0.1 in both directions.

### Output

```
Plot corners (metres):
 [[ 0.  0.]
 [40.  0.]
 [40. 25.]
 [ 0. 25.]]
Transformation matrix:
 [[ 0.08660254 -0.05      ]
 [ 0.05        0.08660254]]
Corners on the map:
 [[ 0.          0.        ]
 [ 3.46410162  2.        ]
 [ 2.21410162  4.16506351]
 [-1.25        2.16506351]]
Determinant: 0.010000000000000004
```

### Interpretation

The program turned the plot into four new map coordinates with one multiplication. The determinant is 0.01, which is 0.1 x 0.1. This means the area on the map is one hundredth of the real area: the real plot is 1,000 square metres and the drawn plot is 10 square map units. A map-making or design program can reuse the same matrix for every point on the map.
