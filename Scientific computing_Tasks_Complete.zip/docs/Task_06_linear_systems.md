# Task 6: Solution of Systems of Linear Equations

Programs: `code/Task_06_linear_systems.py` (original) and `code/Task_06_bakery_flour_oil.py` (new real-world case)

## B. Inputs and mathematical operations

Two server types use different amounts of CPU and memory. Type A uses 4 CPU units and 8 GB, and Type B uses 2 CPU units and 12 GB. The total observed use is 20 CPU units and 72 GB. This gives two equations, written as Ax = b, where A holds the usage numbers, x holds the unknown numbers of servers, and b holds the totals. `np.linalg.solve` finds x. The program then checks the answer by multiplying A by x and comparing it with b. The difference is called the residual.

## Original output

When I ran the original program, it printed:

```
Type A servers: 3
Type B servers: 4
Verification A @ solution: [20. 72.]
Residual: [0. 0.]
Residual norm: 0.0
```

## C. Changing the inputs

I changed the totals from 20 CPU units and 72 GB to 26 CPU units and 76 GB.

| Result | Original totals | New totals |
|---|---|---|
| Type A servers | 3 | 5 |
| Type B servers | 4 | 3 |
| Residual norm | 0.0 | 0.0 |

More total CPU use means more of the CPU-heavy Type A servers. Check by hand: 4(5) + 2(3) = 26 and 8(5) + 12(3) = 76. The residual stayed at zero in both runs, so both answers satisfy the equations.

## D. Meaning of the output

The answer says 3 servers of Type A and 4 of Type B are running. The check A @ solution gives back exactly [20, 72], and the residual is 0. A residual of zero means the computed answer reproduces the known totals. It is a good habit to check a solution this way.

## E. Modified real-world case

### New assumptions

- A bakery makes mandazi and chapati.
- One batch of mandazi uses 3 cups of flour and 1 cup of oil.
- One batch of chapati uses 2 cups of flour and 2 cups of oil.
- Today the bakery used 24 cups of flour and 12 cups of oil.
- All the numbers are assumed illustrative values.

### Input data

Flour and oil use per batch: A = [[3, 2], [1, 2]]. Totals used: b = [24, 12].

### Output

```
Batches of mandazi: 6
Batches of chapati: 3
Verification A @ solution: [24. 12.]
Residual norm: 0.0
```

### Interpretation

The bakery made 6 batches of mandazi and 3 batches of chapati. Check: 3(6) + 2(3) = 24 cups of flour, and 1(6) + 2(3) = 12 cups of oil. The residual is zero. The same method can work out what was produced from the amount of ingredients used.
