# Task 3: Mathematical Functions and Vectorization

Programs: `code/Task_03_vectorization.py` (original) and `code/Task_03_vat_prices.py` (new real-world case)

## B. Inputs and mathematical operations

The input is one million random network latency readings in milliseconds, between 5 and 250 (the random seed is 42, so the numbers repeat). The operation is to convert each reading to seconds (divide by 1000) and then square it. The program does this twice: once with a Python loop, and once with one vectorized NumPy expression. It uses `timeit` to measure how long each takes.

## Original output

When I ran the original program, it printed:

```
First five squared latency values: [0.03787665 0.01266192 0.04637842 0.03092504 0.00078812]
Loop time: 0.1076 s
Vectorized time: 0.0027 s
Approximate speed-up: 39.7x
```

The loop and vectorized times depend on your computer, so yours will be different.

## C. Changing the inputs

I reduced the number of readings from 1,000,000 to 100,000.

| Result | 1,000,000 readings | 100,000 readings |
|---|---|---|
| Loop time | 0.1076 s | 0.0108 s |
| Vectorized time | 0.0027 s | 0.0004 s |
| Speed-up | 39.7x | 26.4x |

Both methods took less time, because there was ten times less data. The speed-up stayed large, so vectorization is much faster whatever the size. The exact times depend on the computer, so my numbers will differ a little from yours.

## D. Meaning of the output

The first five squared values are the same in both runs, which shows that the vectorized code gives the same answer as the loop. The only difference is speed. Vectorization is quicker because NumPy runs the repeated work in fast compiled code, instead of Python repeating each step one at a time. This matters for large datasets, such as sensor readings or images.

## E. Modified real-world case

### New assumptions

- A shop has one million item prices in KES, between 50 and 5,000 (assumed values).
- VAT is 16% (assumed rate) and is added to every price.
- The aim is to compare a loop with a vectorized calculation.

### Input data

One million random prices between 50 and 5,000 KES (seed 42). VAT rate: 0.16.

### Output

```
First three prices with VAT: [4502.05563081 2578.04000106 4988.06925613]
Total VAT collected: 404,020,969.13 KES
Loop time: 0.1156 s
Vectorized time: 0.0014 s
Approximate speed-up: 80.5x
```

### Interpretation

The vectorized code added VAT to one million prices in about 0.0014 seconds. The loop took about 0.1156 seconds, so vectorization was about 80 times faster. The total VAT came to about KES 404 million on these made-up prices. In a real shop or tax system, calculations like this run on millions of records, so a vectorized approach saves a lot of time.
