# Task 9: Eigenvalues and Eigenvectors

Programs: `code/Task_09_eigenvalues.py` (original) and `code/Task_09_whatsapp_group.py` (new real-world case)

## B. Inputs and mathematical operations

The input is the adjacency matrix of a network of four nodes (A, B, C, D). A 1 means two nodes are connected. The program finds the eigenvalues and eigenvectors with `np.linalg.eig`. It takes the largest eigenvalue and its eigenvector, and divides the eigenvector by its sum, so the scores add up to 1. Each node's score shows how important it is. The last line checks that A v = lambda v.

## Original output

When I ran the original program, it printed:

```
Dominant eigenvalue: 2.561552812808829
Eigenvector-based importance:
A: 0.2192
B: 0.2808
C: 0.2808
D: 0.2192
Verification error: 1.5059797815742444e-15
```

## C. Changing the inputs

I added a link between nodes A and D, so every node is now connected to every other node.

| Result | Original network | After adding A-D |
|---|---|---|
| Dominant eigenvalue | 2.5616 | 3.0 |
| Score of A | 0.2192 | 0.2500 |
| Score of B | 0.2808 | 0.2500 |
| Score of C | 0.2808 | 0.2500 |
| Score of D | 0.2192 | 0.2500 |

Once every node has the same number of links, every node has the same importance, so each score becomes 0.25. The dominant eigenvalue rose from 2.56 to 3 because the network is now more connected (each node has 3 links).

## D. Meaning of the output

Nodes B and C have three connections each, while A and D have only two. So B and C score highest at 0.2808. The verification error is around 1e-15, so A v equals lambda v apart from round-off error. The eigenvector tells us which nodes are best connected, which is the idea behind ranking pages or finding the key people in a network.

## E. Modified real-world case

### New assumptions

- Five friends are in a WhatsApp network. A 1 means that two friends message each other.
- The links are assumed illustrative values.
- Importance is measured by the dominant eigenvector, which also counts how well connected a person's contacts are.

### Input data

Links: A-B, A-C, B-C, B-D, C-D, D-E (five people, A to E).

### Output

```
Dominant eigenvalue: 2.6412
A: 0.1905
B: 0.2515
C: 0.2515
D: 0.2223
E: 0.0842
```

### Interpretation

B and C score highest at 0.2515 each. D scores 0.2223, even though D has three contacts like B and C. The reason is that one of D's contacts is E, who has only one link. E scores lowest at 0.0842 and A scores 0.1905. This shows that the eigenvector measure counts not only how many contacts a person has, but also how well connected those contacts are.
