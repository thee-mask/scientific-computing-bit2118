# Task 19: Numerical Optimization

Programs: `code/Task_19_optimization.py` (original) and `code/Task_19_feed_mix.py` (new real-world case)

## B. Inputs and mathematical operations

The problem is to choose how many units of two server types to run at the lowest cost. Type A costs 12 per unit and gives capacity 100. Type B costs 18 per unit and gives capacity 170. The total capacity must be at least 1,000. The cost is the objective function, the capacity is an inequality constraint, and both amounts must be zero or more. `minimize` with the SLSQP method solves it. The program then tests whole-number combinations of servers.

## Original output

When I ran the original program, it printed:

```
Optimization success: True
Type A allocation: 0.000
Type B allocation: 5.882
Total capacity: 1000.00
Minimum planning cost: 105.88
Best nearby integer solution: (108, 0, 6, 1020)
```

## C. Changing the inputs

I raised the required capacity from 1,000 to 1,500.

| Result | Capacity 1000 | Capacity 1500 |
|---|---|---|
| Type A | 0.000 | 0.000 |
| Type B | 5.882 | 8.824 |
| Minimum cost | 105.88 | 158.82 |
| Best whole-server solution | 0 A, 6 B, cost 108 | 0 A, 9 B, cost 162 |

A higher requirement needs more capacity, so the cost rises in proportion. Only Type B is used in both cases.

## D. Meaning of the output

Type A costs 12 / 100 = 0.12 per unit of capacity and Type B costs 18 / 170 = 0.106 per unit. Type B is cheaper per unit of capacity, so the optimizer uses only Type B and meets the capacity limit exactly. When only whole servers are allowed, 6 servers give a capacity of 1,020 at a cost of 108, a little more than 105.88, which is the price of using whole servers.

## E. Modified real-world case

### New assumptions

- A farmer mixes maize bran and soya meal for a flock.
- Bran costs 30 KES per kg and soya meal costs 55 KES per kg.
- Bran gives 0.08 kg of protein and 3.0 energy units per kg. Soya gives 0.40 kg of protein and 2.5 energy units per kg.
- The flock needs at least 4 kg of protein and 60 energy units a day.
- All prices and nutrient values are assumed illustrative values.

### Input data

Objective: minimise 30a + 55b. Constraints: 0.08a + 0.40b >= 4 and 3.0a + 2.5b >= 60, with a, b >= 0.

### Output

```
Optimization success: True
Maize bran: 14.00 kg
Soya meal: 7.20 kg
Protein supplied: 4.00 kg
Energy supplied: 60.00 units
Minimum cost: 816.00 KES
```

### Interpretation

The cheapest mix is 14.00 kg of maize bran and 7.20 kg of soya meal, which costs 816.00 KES per day. Both limits are met exactly, with 4.00 kg of protein and 60.00 energy units. Bran is cheap but low in protein, and soya is rich in protein but expensive, so the best answer mixes the two. The farmer cannot lower the cost without going below the needed protein or energy.
