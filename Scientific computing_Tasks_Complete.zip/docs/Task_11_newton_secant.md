# Task 11: Root Finding: Newton-Raphson and Secant Methods

Programs: `code/Task_11_newton_secant.py` (original) and `code/Task_11_loan_rate.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are an investment of 10,000 followed by yearly cash inflows of 3,000, 3,500, 4,000 and 2,500. The net present value NPV(r) adds each cash flow divided by (1 + r) raised to the number of years. The internal rate of return (IRR) is the rate r where NPV(r) = 0. Newton-Raphson uses the formula and its derivative to move towards the root. The secant method uses two starting values and the slope between them instead of a derivative.

## Original output

When I ran the original program, it printed:

```
IRR using Newton-Raphson: 11.542461%
IRR using Secant method: 11.542461%
NPV at Newton solution: 0.000000
```

## C. Changing the inputs

I changed the last cash inflow from 2,500 to 3,500.

| Result | Original | After the change |
|---|---|---|
| IRR (Newton-Raphson) | 11.542461% | 14.456060% |
| IRR (Secant) | 11.542461% | 14.456060% |

A bigger final payment makes the investment more profitable, so the rate of return rises from about 11.5% to about 14.5%. Both methods still agree.

## D. Meaning of the output

The IRR of 11.54% is the yearly rate at which the investment exactly breaks even in today's money. The NPV at the answer is 0.000000, which confirms that the root is correct. Newton-Raphson and secant reach the same answer, but secant does not need the derivative, so it is useful when the derivative is hard to write.

## E. Modified real-world case

### New assumptions

- A boda boda rider borrows KES 120,000.
- The rider repays KES 11,500 at the end of each month for 12 months.
- The question is what monthly interest rate this loan really charges.
- All the loan figures are assumed illustrative values.

### Input data

Cash flows: -120,000 at the start, then +11,500 for each of 12 months (written as the lender receives them).

### Output

```
Monthly rate (Newton-Raphson): 2.2185%
Monthly rate (Secant): 2.2185%
Simple yearly rate (monthly x 12): 26.62%
Effective yearly rate: 30.12%
Total repaid: KES 138,000
```

### Interpretation

Both methods find a monthly rate of 2.2185%. Multiplying by 12 gives a simple yearly rate of about 26.62%, and compounding gives an effective yearly rate of about 30.12%. The rider repays KES 138,000 in total, which is KES 18,000 more than was borrowed. Knowing the true rate helps a borrower compare loans that are advertised in different ways.
