# Task 7: Gaussian Elimination and LU Decomposition

Programs: `code/Task_07_gaussian_lu.py` (original) and `code/Task_07_room_heat.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are one 3 x 3 coefficient matrix A and three different measurement vectors b. LU decomposition splits A into a lower triangular part L and an upper triangular part U. The program factors A once with `lu_factor`, then reuses that factorisation to solve each b with `lu_solve`. It checks each answer with the residual, and compares the first answer with the direct solver `np.linalg.solve`.

## Original output

When I ran the original program, it printed:

```
Measurement set 1
Solution: [5. 5. 5.]
Residual norm: 0.0

Measurement set 2
Solution: [5.31707317 5.26829268 4.75609756]
Residual norm: 1.7763568394002505e-15

Measurement set 3
Solution: [4.90243902 5.6097561  5.53658537]
Residual norm: 0.0

Direct solution for first set: [5. 5. 5.]
```

## C. Changing the inputs

I changed the last value of the third measurement vector from 11 to 20.

| Result | Original | After the change |
|---|---|---|
| Set 1 solution | [5, 5, 5] | [5, 5, 5] |
| Set 2 solution | [5.317, 5.268, 4.756] | [5.317, 5.268, 4.756] |
| Set 3 solution | [4.902, 5.610, 5.537] | [5.122, 6.488, 8.829] |

Only the third answer changed, because only the third measurement changed. The matrix A stayed the same, so the factorisation was still valid. This is the advantage of LU: A is factored once and reused for any new b.

## D. Meaning of the output

The solutions are the unknown values that match each set of measurements. The residual norms are around 1e-15, which is zero apart from tiny floating-point round-off. The direct solution for the first set matches the LU answer. This shows that LU gives the same result as the direct method, but it is cheaper when the same matrix is used many times.

## E. Modified real-world case

### New assumptions

- Three connected rooms in a building. The numbers show how much each room is warmer than the outside air.
- Heat flows between neighbouring rooms, which gives the same kind of matrix every day (assumed values).
- Each day the heater settings change, so b changes but A does not.

### Input data

A = [[3, -1, 0], [-1, 3, -1], [0, -1, 3]]. Heater settings: day 1 = [20, 10, 20], day 2 = [30, 10, 30], day 3 = [20, 20, 20].

### Output

```
Day 1: room temperatures [10. 10. 10.], residual norm 7.11e-15
Day 2: room temperatures [14.286 12.857 14.286], residual norm 1.78e-15
Day 3: room temperatures [11.429 14.286 11.429], residual norm 0.00e+00
```

### Interpretation

On day 1 every room is 10 degrees above the outside air. On day 2 the stronger heating in rooms 1 and 3 makes them 14.286 degrees warmer, and the middle room 12.857 degrees. On day 3 the middle room gets the heat, and it becomes the warmest at 14.286. The program factored A once and solved three days quickly. A real simulation would do the same for thousands of time steps.
