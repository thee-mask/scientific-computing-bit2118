# Task 14: Curve Fitting and Approximation

Programs: `code/Task_14_curve_fitting.py` (original) and `code/Task_14_maize_fertilizer.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are seven pairs of numbers: concurrent users (50 to 350) and server response time in milliseconds. The program fits the quadratic model y = ax^2 + bx + c with `curve_fit`, which uses least squares to choose a, b and c so the curve is as close as possible to the data. It measures the fit with the RMSE, the typical size of the gap between the data and the curve, and predicts the response time at 400 users.

## Original output

When I ran the original program, it printed:

```
Fitted model: y = 0.002167x^2 + -0.1345x + 85.00
RMSE: 1.55 ms
Predicted response at 400 users: 377.86 ms
```

## C. Changing the inputs

I changed the last measurement (at 350 users) from 305 ms to 400 ms.

| Result | Original | After the change |
|---|---|---|
| Fitted model | y = 0.002167x^2 - 0.1345x + 85.00 | y = 0.004429x^2 - 0.8357x + 125.71 |
| RMSE | 1.55 ms | 18.83 ms |
| Prediction at 400 users | 377.86 ms | 500.00 ms |

One changed point pulled the whole curve and made the fit much worse. The RMSE rose from 1.55 to 18.83 ms, so the quadratic no longer follows the data well. The prediction also changed a lot. This shows that predictions depend strongly on the data, and that a single unusual reading (an outlier) can mislead a fitted model.

## D. Meaning of the output

The curve rises slowly at first and then more steeply, which means the server slows down faster as more users arrive. An RMSE of 1.55 ms means the curve is, on average, within about 1.5 ms of the measurements, so it is a good fit.

![Server response-time curve fitting](Task_14_graph.png)

## E. Modified real-world case

### New assumptions

- A farmer measures maize yield in bags per acre at different amounts of fertilizer in kg per acre.
- A quadratic curve is assumed to describe the pattern: yield rises, then levels off and falls.
- The data values are assumed illustrative values, not measured data.

### Input data

Fertilizer (kg per acre): 0, 20, 40, 60, 80, 100. Yield (bags per acre): 8.0, 14.0, 18.0, 20.0, 20.5, 19.0.

### Output

```
Fitted model: y = -0.00230x^2 + 0.3392x + 8.05
RMSE: 0.07 bags per acre
Fertilizer for the highest fitted yield: 73.8 kg per acre
Fitted yield at that amount: 20.56 bags per acre
```

### Interpretation

The fitted curve has a negative x^2 term, so it rises and then falls. The RMSE of 0.07 bags per acre means the curve fits the data very closely. The curve peaks at about 73.8 kg of fertilizer per acre, with a yield of about 20.56 bags. Past that amount, more fertilizer does not give more maize, so it only adds cost. A farmer could use this to choose how much fertilizer to buy.

![Maize yield against fertilizer](Task_14_maize_graph.png)
