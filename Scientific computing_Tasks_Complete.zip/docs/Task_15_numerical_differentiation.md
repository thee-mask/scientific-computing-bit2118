# Task 15: Numerical Differentiation

Programs: `code/Task_15_numerical_differentiation.py` (original) and `code/Task_15_tank_level.py` (new real-world case)

## B. Inputs and mathematical operations

The inputs are the position of a vehicle in metres at times 0 to 6 seconds. Speed is the rate of change of position. The program estimates it with differences: a forward difference at the start, central differences in the middle, using the points on either side, and a backward difference at the end. Each is the change in position divided by the change in time.

## Original output

When I ran the original program, it printed:

```
t=0s, position=0.0m, estimated speed=4.80m/s
t=1s, position=4.8m, estimated speed=5.10m/s
t=2s, position=10.2m, estimated speed=5.65m/s
t=3s, position=16.1m, estimated speed=6.25m/s
t=4s, position=22.7m, estimated speed=6.95m/s
t=5s, position=30.0m, estimated speed=7.65m/s
t=6s, position=38.0m, estimated speed=8.00m/s
```

## C. Changing the inputs

I changed the position at t = 3 s from 16.1 m to 17.0 m.

| Time | Original speed | After the change |
|---|---|---|
| t = 2 s | 5.65 m/s | 6.10 m/s |
| t = 3 s | 6.25 m/s | 6.25 m/s |
| t = 4 s | 6.95 m/s | 6.50 m/s |

The speed at t = 3 did not change. A central difference uses the points on either side, t = 2 and t = 4, and does not use the point itself. The speeds at t = 2 and t = 4 did change, because both use the value at t = 3. For example, at t = 2 the new speed is (17.0 - 4.8) / 2 = 6.10 m/s.

## D. Meaning of the output

The speed rises steadily from 4.8 m/s to 8.0 m/s, so the vehicle is speeding up. The graph rises as a gentle upward line. The end points use one-sided differences, so they are usually a little less accurate than the middle points.

![Speed estimated from GPS position data](Task_15_graph.png)

## E. Modified real-world case

### New assumptions

- Water flows into a tank, and the level in litres is read every 5 minutes.
- The aim is to estimate the inflow rate in litres per minute.
- The levels are assumed illustrative values.

### Input data

Time (minutes): 0, 5, 10, 15, 20, 25, 30. Level (litres): 200, 245, 285, 320, 350, 375, 395.

### Output

```
t=0 min, level=200 L, inflow rate=9.00 L/min
t=5 min, level=245 L, inflow rate=8.50 L/min
t=10 min, level=285 L, inflow rate=7.50 L/min
t=15 min, level=320 L, inflow rate=6.50 L/min
t=20 min, level=350 L, inflow rate=5.50 L/min
t=25 min, level=375 L, inflow rate=4.50 L/min
t=30 min, level=395 L, inflow rate=4.00 L/min
```

### Interpretation

The inflow rate falls from 9 litres per minute at the start to 4 litres per minute at the end. The tank is filling more slowly as it fills up. Over 30 minutes it gained 195 litres. The graph slopes downward, and a rate that keeps falling suggests the tank is close to a limit. A water manager could use this to decide when the tank will be full.

![Tank inflow rate](Task_15_tank_graph.png)
