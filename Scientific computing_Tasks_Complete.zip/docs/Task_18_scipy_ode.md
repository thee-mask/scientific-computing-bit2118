# Task 18: Numerical Solution of ODEs Using SciPy

Programs: `code/Task_18_scipy_ode.py` (original) and `code/Task_18_sir_outbreak.py` (new real-world case)

## B. Inputs and mathematical operations

The model is a charging RC circuit: dV/dt = (Vs - V) / (RC). The inputs are a supply voltage of 5 V, a resistance of 1,000 ohms, a capacitance of 0.001 farads and a starting voltage of 0 V. `solve_ivp` chooses its own step sizes to solve the equation from 0 to 5 seconds. The program compares the answer with the exact formula V = Vs(1 - e^(-t / RC)).

## Original output

When I ran the original program, it printed:

```
Solver success: True
Capacitor voltage at 5 s: 4.9663 V
Maximum error against exact solution: 9.282e-10 V
```

## C. Changing the inputs

I changed the resistance from 1,000 ohms to 2,000 ohms.

| Result | R = 1000 | R = 2000 |
|---|---|---|
| Time constant RC | 1 s | 2 s |
| Voltage at 5 s | 4.9663 V | 4.5896 V |
| Maximum error vs exact | 9.282e-10 V | 6.740e-10 V |

With more resistance the capacitor charges more slowly, so after 5 seconds it has reached less of the 5 V. Check by hand: 5(1 - e^(-2.5)) = 4.5896 V. The solver was accurate in both cases.

## D. Meaning of the output

The voltage starts at 0 V and rises quickly at first, then slowly levels out close to 5 V. After 5 seconds it is 4.9663 V, almost fully charged. The solver and the exact curve lie on top of each other, with a maximum error of about 1e-9 V. This shows that `solve_ivp` is very accurate.

![RC circuit charging](Task_18_graph.png)

## E. Modified real-world case

### New assumptions

- A flu outbreak in a school of 1,000 students, using the SIR model (Susceptible, Infected, Recovered).
- One student is infected at the start.
- The infection rate is 0.3 per day and the recovery rate is 0.1 per day (both assumed).
- The simulation runs for 100 days.

### Input data

N = 1000, beta = 0.3, gamma = 0.1, starting values: 999 susceptible, 1 infected, 0 recovered.

### Output

```
Solver success: True
Peak number infected: 301 students on day 38.2
Total who caught the flu by day 100: 940
Students never infected: 60
```

### Interpretation

The number of infected students peaks at about 301 on day 38. By day 100 about 940 students have caught the flu, and 60 never did. The infection rate is three times the recovery rate, which is why most of the school gets ill. A school could use a model like this to see how much a measure that lowers the infection rate would flatten the peak.

![Flu outbreak in a school](Task_18_sir_graph.png)
