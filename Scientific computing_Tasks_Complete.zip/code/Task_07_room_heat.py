import numpy as np
from scipy.linalg import lu_factor, lu_solve

# Case: temperature (degrees above outside) of three connected rooms.
# The coefficient matrix stays the same; heater settings change each day.
A = np.array([
    [3.0, -1.0, 0.0],
    [-1.0, 3.0, -1.0],
    [0.0, -1.0, 3.0]
])

heater_settings = [
    np.array([20.0, 10.0, 20.0]),
    np.array([30.0, 10.0, 30.0]),
    np.array([20.0, 20.0, 20.0])
]

lu, piv = lu_factor(A)   # factor once

for day, b in enumerate(heater_settings, start=1):
    x = lu_solve((lu, piv), b)
    print(f"Day {day}: room temperatures {np.round(x, 3)}, "
          f"residual norm {np.linalg.norm(b - A @ x):.2e}")
