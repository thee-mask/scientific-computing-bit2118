import numpy as np
import timeit

# Case: add 16% VAT to one million shop prices (KES)
rng = np.random.default_rng(42)
prices = rng.uniform(50, 5000, 1_000_000)
vat_rate = 0.16

def loop_version():
    result = []
    for p in prices:
        result.append(p * (1 + vat_rate))
    return result

def vectorized_version():
    return prices * (1 + vat_rate)

loop_time = timeit.timeit(loop_version, number=1)
vector_time = timeit.timeit(vectorized_version, number=3) / 3

with_vat = vectorized_version()
print("First three prices with VAT:", with_vat[:3])
print(f"Total VAT collected: {(with_vat - prices).sum():,.2f} KES")
print(f"Loop time: {loop_time:.4f} s")
print(f"Vectorized time: {vector_time:.4f} s")
print(f"Approximate speed-up: {loop_time/vector_time:.1f}x")
