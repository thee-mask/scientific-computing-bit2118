import numpy as np

# Case: daily rainfall readings (mm) from a rain gauge on a farm
rain_mm = np.array([0.0, 0.0, 12.5, 8.0, 0.0, 3.2, 25.4, 0.0, 0.0, 5.1, 14.8, 0.0])
farm_area_m2 = 2000.0   # assumed farm size

total_mm = np.sum(rain_mm)
mean_mm = np.mean(rain_mm)
wettest_day = np.argmax(rain_mm) + 1

# 1 mm of rain on 1 square metre = 1 litre of water (vectorized for all days)
litres = rain_mm * farm_area_m2

print(f"Total rainfall: {total_mm:.1f} mm")
print(f"Mean daily rainfall: {mean_mm:.2f} mm")
print(f"Wettest day: day {wettest_day} with {rain_mm.max():.1f} mm")
print(f"Total water received by the farm: {litres.sum():,.0f} litres")
