import os
import numpy as np
import matplotlib.pyplot as plt

# Case: drug concentration in the blood falls as dC/dt = -k*C
C0 = 200.0       # starting concentration (mg/L), assumed
k = 0.2          # elimination rate per hour, assumed
h = 0.5          # step size in hours
end_time = 12.0

time = np.arange(0, end_time + h, h)
conc = np.zeros_like(time)
conc[0] = C0
for i in range(len(time) - 1):
    conc[i + 1] = conc[i] + h * (-k * conc[i])

exact = C0 * np.exp(-k * time)

print(f"Euler concentration after 12 h: {conc[-1]:.2f} mg/L")
print(f"Exact concentration after 12 h: {exact[-1]:.2f} mg/L")
print(f"Final absolute error: {abs(conc[-1] - exact[-1]):.3f} mg/L")

plt.plot(time, conc, marker="o", label="Euler")
plt.plot(time, exact, label="Exact solution")
plt.xlabel("Time (hours)")
plt.ylabel("Concentration (mg/L)")
plt.title("Drug concentration decay")
plt.legend()
plt.grid(True)
os.makedirs("docs", exist_ok=True)
plt.savefig("docs/Task_17_drug_graph.png", dpi=150)
plt.show()
