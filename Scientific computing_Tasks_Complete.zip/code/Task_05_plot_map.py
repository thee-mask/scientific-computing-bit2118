import numpy as np

# Case: draw a rectangular plot of land (40 m x 25 m) on a map,
# rotated by 30 degrees and scaled down to 1/10 of its size.
corners = np.array([
    [0.0, 0.0],
    [40.0, 0.0],
    [40.0, 25.0],
    [0.0, 25.0]
])

angle = np.deg2rad(30)
rotation = np.array([
    [np.cos(angle), -np.sin(angle)],
    [np.sin(angle),  np.cos(angle)]
])
scale = np.array([
    [0.1, 0.0],
    [0.0, 0.1]
])

transformation = rotation @ scale
map_points = corners @ transformation.T

print("Plot corners (metres):\n", corners)
print("Transformation matrix:\n", transformation)
print("Corners on the map:\n", map_points)
print("Determinant:", np.linalg.det(transformation))
