import numpy as np
from scipy.optimize import minimize

# Case: a farmer mixes two feeds for a flock at the lowest cost.
# a = kg of maize bran, b = kg of soya meal (assumed prices and contents)
# Cost per kg: bran 30 KES, soya 55 KES
# Protein per kg: bran 0.08 kg, soya 0.40 kg  -> need at least 4 kg protein
# Energy per kg: bran 3.0 units, soya 2.5 units -> need at least 60 units
def cost(z):
    a, b = z
    return 30*a + 55*b

constraints = [
    {"type": "ineq", "fun": lambda z: 0.08*z[0] + 0.40*z[1] - 4},
    {"type": "ineq", "fun": lambda z: 3.0*z[0] + 2.5*z[1] - 60},
]
bounds = [(0, None), (0, None)]

solution = minimize(cost, x0=[10, 10], method="SLSQP",
                    bounds=bounds, constraints=constraints)
a, b = solution.x

print("Optimization success:", solution.success)
print(f"Maize bran: {a:.2f} kg")
print(f"Soya meal: {b:.2f} kg")
print(f"Protein supplied: {0.08*a + 0.40*b:.2f} kg")
print(f"Energy supplied: {3.0*a + 2.5*b:.2f} units")
print(f"Minimum cost: {solution.fun:.2f} KES")
