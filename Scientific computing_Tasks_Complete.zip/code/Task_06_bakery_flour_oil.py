import numpy as np

# Case: a bakery makes mandazi and chapati.
# x = batches of mandazi, y = batches of chapati
# Mandazi: 3 cups flour, 1 cup oil per batch
# Chapati: 2 cups flour, 2 cups oil per batch
# Total used today: 24 cups flour and 12 cups oil
A = np.array([
    [3.0, 2.0],
    [1.0, 2.0]
])
b = np.array([24.0, 12.0])

solution = np.linalg.solve(A, b)
residual = b - A @ solution

print(f"Batches of mandazi: {solution[0]:.0f}")
print(f"Batches of chapati: {solution[1]:.0f}")
print("Verification A @ solution:", A @ solution)
print("Residual norm:", np.linalg.norm(residual))
