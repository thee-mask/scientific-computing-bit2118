import os
import numpy as np
import matplotlib.pyplot as plt

# Case: water level in a tank (litres) measured every 5 minutes while it fills.
# Estimate the inflow rate in litres per minute.
time = np.array([0, 5, 10, 15, 20, 25, 30], dtype=float)
level = np.array([200.0, 245.0, 285.0, 320.0, 350.0, 375.0, 395.0])

rate = np.zeros_like(level)
rate[0] = (level[1] - level[0]) / (time[1] - time[0])                 # forward
for i in range(1, len(time) - 1):
    rate[i] = (level[i+1] - level[i-1]) / (time[i+1] - time[i-1])     # central
rate[-1] = (level[-1] - level[-2]) / (time[-1] - time[-2])            # backward

for t, v, r in zip(time, level, rate):
    print(f"t={t:.0f} min, level={v:.0f} L, inflow rate={r:.2f} L/min")

plt.plot(time, rate, marker="o")
plt.xlabel("Time (minutes)")
plt.ylabel("Inflow rate (litres per minute)")
plt.title("Tank inflow rate from level readings")
plt.grid(True)
os.makedirs("docs", exist_ok=True)
plt.savefig("docs/Task_15_tank_graph.png", dpi=150)
plt.show()
