import os
import numpy as np
import matplotlib.pyplot as plt

# Case: a clinic can see 55 patients a day. Arrivals vary randomly
# (Poisson distribution, mean 45, assumed). How often is it overloaded?
rng = np.random.default_rng(42)
capacity = 55
mean_arrivals = 45
N = 100_000

arrivals = rng.poisson(mean_arrivals, N)
overloaded = arrivals > capacity
probability = overloaded.mean()

print(f"Estimated probability of overload: {probability:.4%}")
print(f"Overloaded days: {overloaded.sum()} out of {N}")
print(f"Expected overloaded days in a 30-day month: {probability*30:.2f}")
print("Capacity vs overload probability:")
for cap in [50, 55, 60, 65, 70]:
    print(f"  {cap} patients -> {(arrivals > cap).mean():.4%}")

running = np.cumsum(overloaded) / np.arange(1, N + 1)
idx = np.unique(np.logspace(1, np.log10(N), 200).astype(int)) - 1
plt.semilogx(idx + 1, running[idx])
plt.xlabel("Number of simulated days")
plt.ylabel("Estimated overload probability")
plt.title("Monte Carlo estimate of clinic overload")
plt.grid(True)
os.makedirs("docs", exist_ok=True)
plt.savefig("docs/Task_20_clinic_graph.png", dpi=150)
plt.show()
