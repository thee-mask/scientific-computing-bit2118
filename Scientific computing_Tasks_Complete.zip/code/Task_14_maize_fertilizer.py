import os
import numpy as np
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt

# Case: maize yield (bags per acre) against fertilizer used (kg per acre)
fertilizer = np.array([0, 20, 40, 60, 80, 100], dtype=float)
yield_bags = np.array([8.0, 14.0, 18.0, 20.0, 20.5, 19.0])

def model(x, a, b, c):
    return a*x**2 + b*x + c

(a, b, c), _ = curve_fit(model, fertilizer, yield_bags)
predicted = model(fertilizer, a, b, c)
rmse = np.sqrt(np.mean((yield_bags - predicted)**2))
best_fertilizer = -b / (2*a)

print(f"Fitted model: y = {a:.5f}x^2 + {b:.4f}x + {c:.2f}")
print(f"RMSE: {rmse:.2f} bags per acre")
print(f"Fertilizer for the highest fitted yield: {best_fertilizer:.1f} kg per acre")
print(f"Fitted yield at that amount: {model(best_fertilizer, a, b, c):.2f} bags per acre")

x_plot = np.linspace(0, 100, 200)
plt.scatter(fertilizer, yield_bags, label="Measured yield")
plt.plot(x_plot, model(x_plot, a, b, c), label="Fitted curve")
plt.axvline(best_fertilizer, linestyle="--", linewidth=0.8)
plt.xlabel("Fertilizer (kg per acre)")
plt.ylabel("Maize yield (bags per acre)")
plt.title("Maize yield against fertilizer")
plt.legend()
plt.grid(True)
os.makedirs("docs", exist_ok=True)
plt.savefig("docs/Task_14_maize_graph.png", dpi=150)
plt.show()
