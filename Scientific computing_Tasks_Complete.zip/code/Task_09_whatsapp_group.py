import numpy as np

# Case: who is most influential in a small WhatsApp friend network?
# People: A, B, C, D, E. A 1 means the two people message each other.
A = np.array([
    [0., 1., 1., 0., 0.],
    [1., 0., 1., 1., 0.],
    [1., 1., 0., 1., 0.],
    [0., 1., 1., 0., 1.],
    [0., 0., 0., 1., 0.]
])

eigenvalues, eigenvectors = np.linalg.eig(A)
index = np.argmax(np.real(eigenvalues))
dominant_value = np.real(eigenvalues[index])
vector = np.abs(np.real(eigenvectors[:, index]))
importance = vector / vector.sum()

people = ["A", "B", "C", "D", "E"]
print("Dominant eigenvalue:", round(dominant_value, 4))
for person, score in zip(people, importance):
    print(f"{person}: {score:.4f}")
