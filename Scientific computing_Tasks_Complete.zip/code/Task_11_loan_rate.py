from scipy.optimize import root_scalar

# Case: a boda boda loan. Borrow KES 120,000 and repay KES 11,500
# at the end of each month for 12 months. What monthly rate is charged?
cash_flows = [-120000] + [11500] * 12

def npv(rate):
    return sum(cf / (1 + rate)**t for t, cf in enumerate(cash_flows))

def d_npv(rate):
    return sum(-t * cf / (1 + rate)**(t + 1)
               for t, cf in enumerate(cash_flows) if t > 0)

newton = root_scalar(npv, fprime=d_npv, x0=0.02, method="newton", xtol=1e-12)
secant = root_scalar(npv, x0=0.01, x1=0.05, method="secant", xtol=1e-12)

monthly = newton.root
print(f"Monthly rate (Newton-Raphson): {monthly:.4%}")
print(f"Monthly rate (Secant): {secant.root:.4%}")
print(f"Simple yearly rate (monthly x 12): {monthly*12:.2%}")
print(f"Effective yearly rate: {(1 + monthly)**12 - 1:.2%}")
print(f"Total repaid: KES {11500*12:,}")
