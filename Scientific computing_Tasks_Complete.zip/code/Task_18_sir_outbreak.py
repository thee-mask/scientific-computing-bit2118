import os
import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# Case: a flu outbreak in a school of 1000 students (SIR model)
beta = 0.3      # infection rate per day, assumed
gamma = 0.1     # recovery rate per day, assumed
N = 1000.0

def sir(t, y):
    S, I, R = y
    return [-beta * S * I / N, beta * S * I / N - gamma * I, gamma * I]

t_eval = np.linspace(0, 100, 401)
sol = solve_ivp(sir, (0, 100), [N - 1, 1, 0], t_eval=t_eval, rtol=1e-8, atol=1e-10)

peak = np.argmax(sol.y[1])
print("Solver success:", sol.success)
print(f"Peak number infected: {sol.y[1, peak]:.0f} students on day {sol.t[peak]:.1f}")
print(f"Total who caught the flu by day 100: {sol.y[2, -1] + sol.y[1, -1]:.0f}")
print(f"Students never infected: {sol.y[0, -1]:.0f}")

plt.plot(sol.t, sol.y[0], label="Susceptible")
plt.plot(sol.t, sol.y[1], label="Infected")
plt.plot(sol.t, sol.y[2], label="Recovered")
plt.xlabel("Day")
plt.ylabel("Number of students")
plt.title("Flu outbreak in a school (SIR model)")
plt.legend()
plt.grid(True)
os.makedirs("docs", exist_ok=True)
plt.savefig("docs/Task_18_sir_graph.png", dpi=150)
plt.show()
